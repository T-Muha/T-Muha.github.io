
updateGrid = function (newGrid) {

    for (var i = 0; i < 81; i++) {
        temp = i + 1;
        var tempElem = document.getElementById('gridBox' + temp);
        document.getElementById('gridBox' + temp).innerHTML = newGrid[i];
    }
};

window.onload = function () {
    for (i = 0; i < 9; i++) {
        var div = document.createElement("div");
        div.id = "innerBox" + i;
        div.className = "innerBox";
        document.getElementById("sodokuGrid").appendChild(div);
        for (j = 1; j < 10; j++) {
            var innerDiv = document.createElement("div");
            innerDiv.className = "gridBox";
            temp = i + j + i * 8;
            innerDiv.setAttribute('id',"gridBox" + temp);
            innerDiv.innerHTML = j;
            document.getElementById("innerBox" + i).appendChild(innerDiv);
        }
    }
    tempStr = '';
    for (i = 1; i < 16; i++) {
        if (i < 10) {
            tempStr = 's' + 0 + i;
        }
        else {
            tempStr = 's' + i;
        }
        for (j = 0; j < 3; j++) {
            switch (j) {
                case 0:
                    tempStrTwo = tempStr + "a";
                    break;
                case 1:
                    tempStrTwo = tempStr + "b";
                    break;
                case 2:
                    tempStrTwo = tempStr + "c";
                    break;
            }

            var nameDiv = document.createElement("div");
            nameDiv.id = "levelName" + tempStrTwo;
            nameDiv.setAttribute("class", "levelName");
            nameDiv.innerHTML = tempStrTwo;
            tempColor = 255 - i * 3;
            nameDiv.style.backgroundColor = 'rgb(' + tempColor + ',' + tempColor + ',' + tempColor + ')';
            document.getElementById("ctlPanel").appendChild(nameDiv);

            nameDiv.onmouseenter = function () {
                document.getElementById('invisiDiv').style.backgroundColor = this.style.backgroundColor;
                this.style.backgroundColor = 'darkseagreen';
                this.style.cursor = 'pointer';
            };

            nameDiv.onmouseleave = function () {
                this.style.backgroundColor = document.getElementById('invisiDiv').style.backgroundColor;
            };

            nameDiv.onclick = function () {
                this.style.outline = "solid darkgreen 2px";
                if (document.getElementById('invisiDiv').innerHTML) {
                    document.getElementById(String(document.getElementById('invisiDiv').innerHTML)).style.outline = "none";
                }
                document.getElementById('invisiDiv').innerHTML = String(this.id);
            };
        }
    }
};