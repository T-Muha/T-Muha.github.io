from flask import Flask, render_template, jsonify
import json
from SodokuSolver import SodokuSolverPython
app = Flask(__name__)


def SodokuSolver(levelName):
    solution = SodokuSolverPython(levelName)
    newSolution = []
    check = ['1','2','3','4','5','6','7','8','9','0']
    for i in range(len(solution)):
        print(i)
        print(len(solution))
        if solution[i] in check:
            newSolution.append(solution[i])
    return json.dumps(newSolution)


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/SodokuSolver/')
def sodoku():
    return render_template('SodokuSolverPage.html', runSolver = SodokuSolver)

if __name__ == '__main__':
    app.run(debug=True)